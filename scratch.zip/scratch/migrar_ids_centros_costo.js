/**
 * SCRIPT DE DIAGNÓSTICO: Previsualización de IDs de Centros de Costo
 * Ejecuta este script para ver qué datos se rellenarían en cada solicitud 
 * basándose en la información actual de la tabla DistribucionGasto.
 * NO REALIZA CAMBIOS EN LA BASE DE DATOS.
 */

const Solicitud = require('./models/Solicitud');
const DistribucionGasto = require('./models/DistribucionGasto');
const sequelize = require('./config/database');
require('./associations')(); 

async function diagnostico() {
    console.log('=== INICIANDO DIAGNÓSTICO DE DATOS (LECTURA SOLAMENTE) ===');
    console.log('Este script te mostrará qué Centros de Costo se asignarían a cada solicitud.');
    
    try {
        // Obtener todas las solicitudes
        const solicitudes = await Solicitud.findAll();
        console.log(`\n[INFO] Se encontraron ${solicitudes.length} solicitudes en total.\n`);
        
        console.log('ID | CORRELATIVO | IDS DE CENTROS DE COSTO ENCONTRADOS');
        console.log('---------------------------------------------------------');

        let conDatos = 0;
        let sinDatos = 0;

        for (const solicitud of solicitudes) {
            try {
                // Buscar distribuciones para esta solicitud
                const distribuciones = await DistribucionGasto.findAll({
                    where: { solicitudId: solicitud.id }
                });

                if (distribuciones.length > 0) {
                    const ids = [...new Set(distribuciones.map(d => d.centroCostoId))];
                    console.log(`${solicitud.id.toString().padEnd(3)} | ${solicitud.correlativo.padEnd(20)} | [${ids.join(', ')}]`);
                    conDatos++;
                } else {
                    console.log(`${solicitud.id.toString().padEnd(3)} | ${solicitud.correlativo.padEnd(20)} | [NO SE ENCONTRÓ DISTRIBUCIÓN]`);
                    sinDatos++;
                }
            } catch (err) {
                console.error(`Error leyendo solicitud ID ${solicitud.id}:`, err.message);
            }
        }

        console.log('\n---------------------------------------------------------');
        console.log('=== RESUMEN DEL DIAGNÓSTICO ===');
        console.log(`- Solicitudes con datos recuperables: ${conDatos}`);
        console.log(`- Solicitudes que quedarían vacías: ${sinDatos}`);
        console.log(`- Total procesadas: ${solicitudes.length}`);
        console.log('---------------------------------------------------------');
        console.log('[AVISO] No se ha realizado ninguna modificación en la base de datos.');

    } catch (error) {
        console.error('ERROR AL REALIZAR EL DIAGNÓSTICO:', error);
    } finally {
        await sequelize.close();
        process.exit();
    }
}

diagnostico();
